edit of mOrbular noteskin to slightly match felopes/sillyfangirl skin

types:
- nm: no mines variant

-------------------------------------

requires dbz & multiplybyzero skin (use in etterna)

- eightyfivenine, not author